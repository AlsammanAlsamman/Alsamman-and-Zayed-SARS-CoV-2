#!/usr/bin/python3
#USAGE Python3 Table_1	Table_2	Table_3	Table_4	Table_N
import sys
import re
myfiles=sys.argv[1:]
rows={}
data={}
filerowlen={}
for f in myfiles:
	with open(f,"r") as datafile:
		for line in datafile:
			r=line.strip().split("\t")[0]
			if f in filerowlen:
				if len(line.strip().split("\t")) > filerowlen[f]:
					filerowlen[f]=len(line.strip().split("\t"))
			else:
				filerowlen[f]=len(line.strip().split("\t"))
			rows[r]=1
			if f not in data:
				data[f]={}
			data[f][r]=line.strip()
for myfile in myfiles:
		spacen=filerowlen[myfile]
		mfilename=re.sub(r'\S+\/([\S| ]+)$',r'\1',myfile)
		print((str(mfilename)+"\t")*spacen,end="")
print()

for row in rows:
	for myfile in myfiles:
		if row in data[myfile]:
			rowlen=len(data[myfile][row].split("\t"))
			print(data[myfile][row]+"\t"*(filerowlen[myfile]-rowlen),end="\t")
		else:
			print("NA\t"*(filerowlen[myfile]),end="")
	print()
