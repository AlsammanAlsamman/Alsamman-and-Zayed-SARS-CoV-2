use strict;

if($ARGV[0] eq "")
{
 print "use : get geo files to string gene list";
 return ;
}
my @head;


my %data;
for my $file (@ARGV)
{
 my $l=0;
 open(FILE,$file);
 while(<FILE>)
 {
  chomp();
  my $line=$_;
     $line=~s/\"//g;
  my @line=split(/\t/,$line);

  if($l==0)
  {
    @head=@line;
  }
  else
  {
   for  my $item (0..$#line)
   {       
       push(@{$data{$file}{$head[$item]}},$line[$item]);
   }

  }
      $l++;
 } 
 close FILE;
}

mkdir "GEO_0.01";
my $path=$ARGV[0];
if($path=~m/\//g)
{ 
   $path=~s/(\S+)\/\S+$/\1\//g;
}
else
{
   $path="";
}
foreach my $file (@ARGV)
{
 my @rando_col=@{$data{$file}{"P.Value"}};
 my $file_len =$#rando_col; 
 my $file_name=$file;
       $file_name=~s/\S+\/(\S+)$/\1/g;
 
 open(OFILE,">$path"."GEO_0.01/".$file_name);
 print OFILE join("\t",@head)."\n";
 for my $row (0..$file_len)
 {

   if($data{$file}{"P.Value"}->[$row] <=0.01)
   {
   foreach my $item (@head)
   {
    print OFILE $data{$file}{$item}->[$row]."\t";
   }  
   print OFILE "\n";
   }
 }
 close OFILE;
}
