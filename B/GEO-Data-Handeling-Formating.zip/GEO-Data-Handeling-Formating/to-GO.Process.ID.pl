use strict;

if($ARGV[0] eq "")
{
 print "use : get geo files to string gene list";
 return ;
}
my @head;


my %data;
for my $file (@ARGV)
{
 my $l=0;
 open(FILE,$file);
 while(<FILE>)
 {
  chomp();
  my $line=$_;
     $line=~s/\"//g;
  my @line=split(/\t/,$line);

  if($l==0)
  {
    @head=@line;
  }
  else
  {
   for  my $item (0..$#line)
   {       
       push(@{$data{$file}{$head[$item]}},$line[$item]);
   }

  }
      $l++;
 } 
 close FILE;
}

mkdir "GO.Process.ID_LIST";
my $path=$ARGV[0];
if($path=~m/\//g)
{ 
   $path=~s/(\S+)\/\S+$/\1\//g;
}
else
{
   $path="";
}
foreach my $file (@ARGV)
{
 my @rando_col=@{$data{$file}{"P.Value"}};
 my $file_len =$#rando_col; 
 my $file_name=$file;
       $file_name=~s/\S+\/(\S+)$/\1/g; 
 my %seen_gene;
 open(OFILE,">$path"."GO.Process.ID_LIST/".$file_name);
 print OFILE "GO.Process.ID"."\n";
 for my $row (0..$file_len)
 {
   my @geneiso=split(/\/\/\//,$data{$file}{"GO.Process.ID"}->[$row]);
   foreach my $hit (@geneiso)
  {
   if(!$seen_gene{$hit} && $hit ne "")
     {
       print OFILE $hit."\n";
       $seen_gene{$hit}++;
     }
  }

 }
 close OFILE;
}
