filter_0.01.pl	Filtering GEO2R results using significance of <= 0.01 
filter_0.001.pl	Filtering GEO2R results using significance of <= 0.001 
gene-duplicatio-multiply.py	If you have genes with multiple names speartaed by // ypu can make them as sepreated genes => very useful when comparing different datasets
to-access.pl	Extract genes accession numbers to download gene sequences
to-affy-list.pl	Extract genes Affymatrix numbers
to-chrom-location.pl	Extract genes chromosome location
to-gi-list.pl		Extract gene names to list
to-GO.Component.ID.pl		Extract genes GO component ID
to-GO.Function.ID.pl		Extract Function GO component ID
to-GO.Process.ID.pl		Extract genes GO Process ID
to-p-value.pl			Extract genes p-values
to-string.pl			Extract genes to STRING PPI format
