use strict;

if($ARGV[0] eq "")
{
 print "use : get geo files to string gene list";
 return ;
}
my @head;


my %data;
for my $file (@ARGV)
{
 my $l=0;
 open(FILE,$file);
 while(<FILE>)
 {
  chomp();
  my $line=$_;
     $line=~s/\"//g;
  my @line=split(/\t/,$line);

  if($l==0)
  {
    @head=@line;
  }
  else
  {
   for  my $item (0..$#line)
   {       
       push(@{$data{$file}{$head[$item]}},$line[$item]);
   }

  }
      $l++;
 } 
 close FILE;
}

mkdir "GENE_LIST_P-value";
my $path=$ARGV[0];
if($path=~m/\//g)
{ 
   $path=~s/(\S+)\/\S+$/\1\//g;
}
else
{
   $path="";
}
foreach my $file (@ARGV)
{
 my @rando_col=@{$data{$file}{"P.Value"}};
 my $file_len =$#rando_col; 
 my $file_name=$file;
       $file_name=~s/\S+\/(\S+)$/\1/g; 
 my %seen_gene;
 open(OFILE,">$path"."GENE_LIST_P-value/".$file_name);
 print OFILE "Gene.symbol\tp-value\tp_scale"."\n";
 for my $row (0..$file_len)
 {
   my @geneiso=split(/\/\/\//,$data{$file}{"Gene.symbol"}->[$row]);
   my $p_value= $data{$file}{"P.Value"}->[$row];
   if(!$seen_gene{$geneiso[0]} && $geneiso[0] ne "")
     {
       print OFILE $geneiso[0]."\t".log10($p_value)."\t".p_scale(log10($p_value))."\n";
       $seen_gene{$geneiso[0]}++;
     }
 }
 close OFILE;
}

 sub log10 {
        my $n = shift;
        return (log($n)/log(10))*(-1);
    }

sub p_scale
{
my $p=shift;
if($p <=0)
{
 return 0;
} 

if($p > 0 && $p <= 1)
{
 return 1;
} 
if($p > 1 && $p <= 2)
{
 return 2;
}
if($p > 2 && $p <= 3)
{
 return 3;
}
if($p > 3 && $p <= 4)
{
 return 4;
}
if($p > 4 && $p <= 5)
{
 return 5;
}
}
