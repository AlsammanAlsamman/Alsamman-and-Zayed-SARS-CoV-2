import sys

myfile=open(sys.argv[1],"r")

for i in myfile:
	line=i.strip().split("\t")
	if "///" in line[0]:
		genes=line[0].split("///")
		for g in genes:
			print(g+"\t"+"\t".join(line[1:]))
	else:
		print(i.strip())
