#!/usr/bin/python3
from venn import venn
import pandas as pd

COVID_19 = open('COVID_19.txt', "r")
Ebola = open('Ebola.txt', "r")
H1N1 = open('H1N1.txt', "r")
MERS_CoV = open('MERS_CoV.txt', "r")
SARS_COV = open('SARS_COV.txt', "r")

musicians = {
"COVID_19": set(COVID_19),
"Ebola": set(Ebola),
"H1N1": set(H1N1),
"MERS_CoV": set(MERS_CoV),
"SARS_COV": set(SARS_COV)
}
venn(musicians)
