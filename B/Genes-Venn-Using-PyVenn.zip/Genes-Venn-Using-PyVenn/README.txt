You can use this script or  http://bioinformatics.psb.ugent.be/webtools/Venn/
