library("gplots")
library("RColorBrewer")
data=read.table("logfc-ALL.csv",row.names=1,header=TRUE)
my_palette <- colorRampPalette(c("blue", "yellow", "red"))(n = 299)

col_breaks = c(seq(-7,-2,length=100),  # for blue
    seq(-1.99,2,length=100),           # for yellow
    seq(2.01,7,length=100))             # for red

mat_data=as.matrix(data)

pdf("H-D-M.pdf",pointsize = 2)        # smaller font size

heatmap.2(mat_data,
  main = "Correlation", # heat map title
  notecol="black",      # change font color of cell labels to black
  density.info="none",  # turns off density plot inside color legend
  trace="none",         # turns off trace lines inside the heat map
  col=my_palette,       # use on color palette defined earlier
  breaks=col_breaks,    # enable color transition at specified limits
 margins =c(10,20),     # widens margins around plot 
 dendrogram="row",     # only draw a row dendrogram
  Colv="NA")            # turn off column clustering

dev.off()               # close the PNG device

  margins =c(12,9),     # widens margins around plot

