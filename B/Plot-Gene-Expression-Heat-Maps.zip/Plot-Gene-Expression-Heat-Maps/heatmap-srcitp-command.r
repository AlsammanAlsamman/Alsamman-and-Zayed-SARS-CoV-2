#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
if (length(args)==0) {
  stop()
}

library("gplots")
library("RColorBrewer")

data=read.table("logfc-ALL.csv",row.names=1,header=TRUE,sep="\t")
my_palette <- colorRampPalette(c("blue", "yellow", "red"))(n = 299)

col_breaks = c(
	
    seq(0,0.4,length=100),  # for blue
    seq(0.41,0.7,length=100),           # for yellow
    seq(0.71,1,length=100))             # for red

mat_data=as.matrix(data)

#pdf(paste("SAMMAN",".pdf"),pointsize = 0.000001)        # smaller font size

heatmap.2(mat_data,
  notecol="black",      # change font color of cell labels to black
  density.info="none",  # turns off density plot inside color legend
  trace="none",         # turns off trace lines inside the heat map
  col=my_palette,       # use on color palette defined earlier
  breaks=col_breaks,    # enable color transition at specified limits
 margins =c(15,20),     # widens margins around plot 
 dendrogram="row",     # only draw a row dendrogram
Colv="NA")            # turn off column clustering

#dev.off()               # close the PNG device

#  margins =c(12,9),     # widens margins around plot

