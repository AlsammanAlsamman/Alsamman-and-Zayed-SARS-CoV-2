#!/usr/bin/env Rscript
# RUN : Rscipt Input.txt 
library(tidyverse)
library(ggplot2)
library("RColorBrewer")

args = commandArgs(trailingOnly=TRUE)
if (length(args)==0) {
  stop()
}

data=read.table(args[1],header=TRUE,row.names=1)
pdf(paste(args[1],".pdf"),pointsize = 0.001)
data %>% 
ggplot(aes(sample, Goterm, size = gene_count,color=p.value_log10), margins =c(10,10)) +  
  geom_point() +
 scale_color_gradientn(colours = rainbow(5))+

  xlab("Virus Infection") +
  ylab(paste("Gene Ontology Term Enrichment ","")) +
  ggtitle(args[2]) +
#plot.title = element_text(hjust = 0.5), 
theme(text = element_text(size=5, face = "bold"))
dev.off()
