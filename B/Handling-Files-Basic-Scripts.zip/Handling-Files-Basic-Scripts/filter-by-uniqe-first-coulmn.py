import sys
seen={}
with open(sys.argv[1],"r") as myfile:
	for i in myfile:
		firstitem=i.split("\t")[0].strip()
		if firstitem not in seen:
			print(i,end="")
			seen[firstitem]=1
