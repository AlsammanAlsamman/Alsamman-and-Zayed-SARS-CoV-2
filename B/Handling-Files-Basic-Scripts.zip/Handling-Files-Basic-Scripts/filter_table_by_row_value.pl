use strict;
if($ARGV[0] eq "")
{
  print "usage : filter table depending on row value
         script [row_number] [min] [max] [filename]";
}

my $row_number=shift;
my $min=shift;
my $max=shift;
my $file=shift;
open(FILE,$file);
my %data;
while(<FILE>)
{
   my $text=$_;
   my @line=split(/\t/,$text);
   $line[($row_number-1)]=~s/[\"|\s]//g;
   my $s_r=$line[($row_number-1)];
   if($s_r>=$min&&$s_r<=$max&&$s_r ne "NA"){
   print $text;  
   };
}
close FILE;




