#!/usr/bin/perl
my %list;
#read list
open(FILE,$ARGV[0]);
while(<FILE>)
{
chomp();
my @line=split(/\t/,$_);
$list{$line[0]}=$line[1];
}
close FILE;
# read file

open(FFILE,$ARGV[1]);
while(<FFILE>)
{
chomp();
my @line=split(/\t/,$_);
if($list{$line[0]})
{
 $line[$ARGV[2]]=$list{$line[0]};
}
print join("\t",@line)."\n";
}
close FFILE;

if($ARGV[0] eq "")
{
 print "use:perl script [listfile] [file_replace_in] [column_to_replace]\n";
 print "what: can be used to replace a columns value according to a list of taregt and repalce\n";
}
