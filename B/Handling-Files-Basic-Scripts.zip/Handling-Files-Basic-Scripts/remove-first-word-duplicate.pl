my %seen;
open(FILE,$ARGV[0]);
while(<FILE>)
{
chomp();
my @line=split(/\s+/,$_);
if($seen{$line[0]})
{
 $line[0]="";
}
else
{
$seen{$line[0]}=1;
}
print join("\t",@line)."\n";
}
close FILE;
