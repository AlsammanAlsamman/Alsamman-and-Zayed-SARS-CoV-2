open(FILE,$ARGV[0]);
my %data;
my %column_1;
my %column_2;
my $l=0;
while(<FILE>)
{
chomp();
if($l>0)
{
my @line=split(/\s+/,$_);
$data{$line[0]}{$line[1]}=$line[2];
$column_1{$line[0]}=1;
$column_2{$line[1]}=1;
}
$l++;
}
close FILE;

my @col_1=keys(%column_1);
my @col_2=keys(%column_2);
print "\t".join("\t",@col_2)."\n";
foreach my $c1 (@col_1)
{
  print $c1."\t";
 foreach my $c2 (@col_2)
 {
   if($data{$c1}{$c2})
   {
   print Neglog10($data{$c1}{$c2})."\t";
   }
   else
   {
     print "0\t";
   } 
}
print "\n";
}

sub Neglog10 {
        my $n = shift;
        return -1*(log($n)/log(10));
}


if($ARGV[0] eq "")
{
print "USE: take a three columns table and convert to matrix for heatmap\n";
print "the first two columns suppose to be unrepeatable with each other and have a value \n in the third coumn";
}
