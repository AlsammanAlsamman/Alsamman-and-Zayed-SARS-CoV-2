#!/usr/bin/python3
import sys

mydict={}
with open(sys.argv[1],"r") as myfile:
	for line in myfile:
		linedata=line.strip().split("\t")
		if linedata[0] in mydict:
			if mydict[linedata[0]] < linedata[1]:
				mydict[linedata[0]] = linedata[1]
		else:
			mydict[linedata[0]] = linedata[1]

for k,v in mydict.items():
	print(k+"\t"+v)
		
