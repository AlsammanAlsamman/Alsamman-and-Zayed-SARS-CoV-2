BEGIN {push ( @INC,"/media/yasmeen/591C19936D1BA751/MyLife-Scripts/Main-libraries");}
use sammanmain;
my @lines =sammanmain::read_file($ARGV[0]);
my @selection=split(/-/,$ARGV[1]);
my %seen;
my $sp=$ARGV[2];
foreach my $l (@lines)
{

  my @items=split(/$sp/,$l);
  my @targets;
  foreach my $s (@selection)
  {
    push(@targets,$items[$s-1]);
  }
  my @tarcomb = sammanmain::permutate(\@targets,$#selection+1);
  #print "@$_\n" for @tarcomb;
  my $svalue = 1 ;  #seen value 
  foreach my $ct (@tarcomb)
  {
    my $str=join("\t",@{$ct}); 
    if($seen{$str})
    { 
       $svalue = 0;
    }
    $seen{$str}=1;
  }
  if($svalue == 1)
    {
       print $l."\n";
    } 
}

if($ARGV[0] eq "")
{
print "
SCRIPT [FILE] [COLUMNS-SEPby[-]] SEP

Example:
perl remove-duplicate.pl p-values.txt 1-2 \"\t\"

SAMPLE INPUT
LC	WLFLB	2.8808079733
FLL	AL	2.9261322494
WLFLB	LC	2.8808079733 

SAMPLE OUTPUT
LC	WLFLB	2.8808079733
FLL	AL	2.9261322494

";


}




