#!/usr/bin/perl
my %list;
#read list
my $listexist =0;
my $line=0;
my $columnToReplace=0;

open(FILE,"list");
while(<FILE>)
{
chomp();
$listexist = 1;
if($line !=0)
{
my @line=split(/\t/,$_);
my $first=shift @line;
$list{$first}=join("\t",@line);
}
else
{
 $columnToReplace = $_;
}
$line++;
}
close FILE;
if($listexist==0)
{
 open(RFILE,">ERROR");
 print RFILE "please add list file with name \"list\"
 where first line with the column number; 
Example
1
AS	anthocyanin  stain
WLS	wax layer on the spike
WLLN	wax layer of leg neck
 ";
 close RFILE;
 exit;
}


# read file
open(FFILE,$ARGV[0]);
while(<FFILE>)
{
chomp();
my @line=split(/\t/,$_);
if($list{$line[$columnToReplace]})
{
 $line[$columnToReplace]=$list{$line[$columnToReplace]};
}
print join("\t",@line)."\n";
}
close FFILE;

if($ARGV[0] eq "DO!")
{
 open(RFILE,">ERROR");
 print RFILE "because the file name is DO!\n";
 print RFILE "use:perl script [listfile] [file_replace_in] [column_to_replace]\n";
 print RFILE "what: can be used to replace a columns value according to a list of taregt and repalce\n";
 close RFILE;
 exit;
}
