use strict;
use List::Util qw[min max];
open(FILE,$ARGV[0]);
my @head;
my %data;
my %headdata;
my $l=0;
while(<FILE>)
{
chomp();
 if($l==0)
 {
    @head=split(/\t/,$_);
 }
 else
 {
  my @line = split(/\t/,$_);
  foreach my $hi (1..$#head)
  {
   if($line[$hi] ne "") {
   $data{$line[0]}{$head[$hi]} = $line[$hi];   
   push(@{$headdata{$head[$hi]}},$line[$hi]);
   }
    }
 }
$l++;
}
close FILE;

my %maxmin;
my %headmaxmin;
foreach my $h (keys(%headdata))
{
 my $head=$h;
 my @array=@{$headdata{$h}};
 my $headmax=max(@{$headdata{$h}});
 my $headmin=min(@{$headdata{$h}});
 $headmaxmin{$h}{"max"}=$headmax;
 $headmaxmin{$h}{"min"}=$headmin;
 $headmaxmin{$h}{"count"}=($#array+1);
 foreach my $p (keys(%data))
 {
   if($data{$p}{$h} == $headmax)
   {
    push(@{$maxmin{$h}{"max"}},$p);
   }
   if($data{$p}{$h} == $headmin)
   {
    push(@{$maxmin{$h}{"min"}},$p);
   }
   $headmaxmin{$h}{"total"}+=$data{$p}{$h};
 }
}

if($ARGV[0] eq "")
{
 print "use : summarize table and get the max and minimum and which rows have";
 return ;
}



open(OFILE,">".$ARGV[0]."summary.csv");

###print result
print OFILE "HEAD\tCount\tTotal\tMean\tMin\tMincount\tROWSMACTH\tMAX\tMaxcount\tROWSMACTH\n";
foreach my $h (keys(%headdata))
{
my @min=@{$maxmin{$h}{"min"}};
my @max=@{$maxmin{$h}{"max"}};
my $maxcount=($#max+1);
my $mincount=($#min+1);
my $mean=sprintf("%0.3f",($headmaxmin{$h}{"total"}/$headmaxmin{$h}{"count"}));         
         print OFILE   $h."\t"
         .$headmaxmin{$h}{"count"}."\t"
         .$headmaxmin{$h}{"total"}."\t"
         .$mean."\t" 
         .$headmaxmin{$h}{"min"}."\t".$mincount."\t"
         .join(",",@min)."\t"
         .$headmaxmin{$h}{"max"}."\t".$maxcount."\t"
         .join(",",@max)."\n";

}

close OFILE;


