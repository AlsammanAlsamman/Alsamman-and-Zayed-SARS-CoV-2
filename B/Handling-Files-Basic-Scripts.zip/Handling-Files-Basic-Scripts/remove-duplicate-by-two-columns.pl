open(FILE,$ARGV[0]);
my %seen;
while(<FILE>)
{
chomp();
my @line=split(/\t/,$_);


if(!$seen{$line[0]."-".$line[1]} && !$seen{$line[1]."-".$line[0]} )
{
 print $_."\n";
 $seen{$line[0]."-".$line[1]}=1;
 $seen{$line[1]."-".$line[0]}=1; 
}


}
close FILE;

if($ARG[0] eq "")
{
# print "USE remove-duplicate file column sep"
}
