#!/usr/bin/python3
import sys
dict={}
with open(sys.argv[1]) as list:
	for l in list:
			dict[l.split()[0]]=l.split()[1]
try:
	print(dict[sys.argv[2]])
except:
	pass
