use strict;

#specify the columns 
my %data;
my $firstcol=0;
my $secondcol=5;

foreach my $file(@ARGV)
{
open(FILE,$file);
while(<FILE>)
{
chomp();
my @line=split(/\s+/,$_);
$data{$line[$firstcol]}{$file}=$line[$secondcol]; 
}
close FILE;
}

print "\t",join("\t",@ARGV)."\n"; 
foreach my $row (keys(%data))
{
 print $row."\t";
foreach my $col (@ARGV)
{

 print $data{$row}{$col}."\t";
}
print "\n";
}

if($ARGV[0] eq "")
{
print "use : combining multiple tables by single coulmn value \n";
print "SCRIPT < Tables1.csv Tables2.csv Tables3.csv Tables4.csv >\n";
}
