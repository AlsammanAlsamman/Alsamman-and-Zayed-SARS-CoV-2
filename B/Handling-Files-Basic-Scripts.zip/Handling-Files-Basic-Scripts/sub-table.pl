use strict;

if($ARGV[0] eq "")
{
 print "use : get list of table coumns and print sub columns only for list of files";
 print "it requires list file ";
 return ;
}
my @head;

my %data;
for my $file (@ARGV)
{
 my $l=0;
 open(FILE,$file);
 while(<FILE>)
 {
  chomp();
  my $line=$_;
     $line=~s/\"//g;
  my @line=split(/\t/,$line);
  if($l==0)
  {
    @head=@line;
  }
  else
  {
   for  my $item (0..$#line)
   {
       
       push(@{$data{$file}{$head[$item]}},$line[$item]);
   }

  }
      $l++;
 } 
 close FILE;
}

#Reading list file
 my @list;
 open(LFILE,"list");
 while(<LFILE>)
 {
  chomp();
  my $line=$_;
     $line=~s/\"//g;
  push(@list,$line);
 } 
 close LFILE;

mkdir "FILES-BY-LIST";
my $path=$ARGV[0];
   $path=~s/(\S+)\/\S+$/\1\//g;
foreach my $file (@ARGV)
{
 my @rando_col=@{$data{$file}{$list[0]}};
 my $file_len =$#rando_col; 
 my $file_name=$file;
       $file_name=~s/\S+\/(\S+)$/\1/g;
 open(OFILE,">$path"."FILES-BY-LIST/".$file_name);
 #print headers
 
  foreach my $item (@list)
   {
    print OFILE $item."\t";
   }  
   print OFILE"\n";

  

 for my $row (0..$file_len)
 {
   foreach my $item (@list)
   {
    print OFILE $data{$file}{$item}->[$row]."\t";
   }  
   print OFILE"\n";
 }
 close OFILE;
}
