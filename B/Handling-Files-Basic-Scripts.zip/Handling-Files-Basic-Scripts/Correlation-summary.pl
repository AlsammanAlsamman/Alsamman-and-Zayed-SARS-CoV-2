BEGIN {push ( @INC,"/media/yasmeen/591C19936D1BA751/MyLife-Scripts/Main-libraries");}
use strict;
use sammanmain;
my @heads;
my %data;
my %count;
my $maxmaxpos=-1;
my $maxmaxneg=1;
open(FILE,$ARGV[0]);
my $l=0;
while(<FILE>)
{
 chomp();
 if($l==0)
  {
   @heads=split(/\t/,$_);
  }
  else
  {
   my @lines=split(/\t/,$_);
    
   for my $item (1..$#lines)
   {
     if($lines[$item] =~m/\*/g)
       { 
          if(!$data{$lines[0]}{"maxpos"}){$data{$lines[0]}{"maxpos"}=-1}
          if(!$data{$lines[0]}{"maxneg"}){$data{$lines[0]}{"maxneg"}=1}
          push(@{$data{$lines[0]}{"values"}},[$heads[$item],$lines[$item]]);
          push(@{$data{$heads[$item]}{"values"}},[$lines[0],$lines[$item]]);
          $lines[$item]=~s/\*//g;
         
         if(!$count{$heads[$item]."-".$lines[0]}||!$count{$lines[0]."-".$heads[$item]})
           {$count{$lines[0]."-".$heads[$item]}=1;}
         

           if($lines[$item]>=$data{$lines[0]}{"maxpos"})
           {$data{$lines[0]}{"maxpos"} = $lines[$item]}
           if($lines[$item]<=$data{$lines[0]}{"maxneg"})
           {$data{$lines[0]}{"maxneg"} = $lines[$item]}

           if($lines[$item]>=$data{$heads[$item]}{"maxpos"})
           {$data{$heads[$item]}{"maxpos"} = $lines[$item]}
           if($lines[$item]<=$data{$heads[$item]}{"maxneg"})
           {$data{$heads[$item]}{"maxneg"} = $lines[$item]}
           if($lines[$item]>=$maxmaxpos){$maxmaxpos=$lines[$item]};
           if($lines[$item]<=$maxmaxneg){$maxmaxneg=$lines[$item]}; 
       }
   }
}
$l++; 
}
close FILE;

my @ccount=keys(%count);
print "ALLCORRELATIONS ARE : ". ($#ccount+1)."\n";
foreach my $trait(keys(%data))
{
 print $trait;
foreach my $cor(@{$data{$trait}{"values"}})
{
 my $corclear = $cor->[1];
    $corclear =~s/\*//g; 
 print "\t".$cor->[0]."\t".$cor->[1]; 
 if($corclear == $data{$trait}{"maxpos"})
   {
    print "\t"."MAX_POSITIVE";
   }
  if($corclear == $data{$trait}{"maxneg"})
   {
    print "\t"."MAX_NEGATIVE";
   }
  if($corclear == $maxmaxneg)
   {
    print "\t\t"."ALL_MAX_NEGATIVE";
   }
  if($corclear == $maxmaxpos)
   {
    print "\t\t"."ALL_MAX_POSITIVE";
   }



print "\n";
}  
}

if($ARGV[0] eq "DO!")
{
 open(ERFILE,">ERORR");
 print ERFILE "use : print significant correlations where * is there";
 close ERFILE;
 return ;
}
