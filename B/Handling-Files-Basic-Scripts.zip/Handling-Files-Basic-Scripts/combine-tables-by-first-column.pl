use strict;
my @files;
my %items;

foreach my $fi(@ARGV)
{
 my %data_file = read_file($fi);
 push(@files,\%data_file);
}
 foreach my $item(keys(%items))
 {
         my $item_exist = 1;
	 foreach my $file (@files)
	 {
                if($file->{$item} eq "")
                {
		 $item_exist = 0;
                }
	 }
         if($item_exist==1) #item must exists in all files
         {
         	print $item."\t";
          foreach my $file (@files)
	  {
            my $line_table=$file->{$item};
            print $line_table."\t";
          }
         }


if($item_exist==1) #item must exists in all files
{
 print "\n";
}
 } 
sub read_file
{
my ($file)=@_;
my %data;
open(FILE,$file);
while(<FILE>)
{
 chomp();
 my @line=split(/\t/,$_);
 if($line[1] eq "")
 {
 	$line[1]+=0;
 }
 my @value=@line;
    shift(@value);
 $data{$line[0]}=join("\t",@value);
 $items{$line[0]}=1; 
}
close FILE;
return %data;
}
if($ARGV[0] eq "")
{
 print "USE : SCRIPT [TABLES_tab_del]
 USAGE: it combines more than one file using the first coulmn 
        > the first column must exist in all files
 ";
 return ;
}
