#!/usr/bin/python3
import sys
from difflib import SequenceMatcher

def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

marker={}
myfile=open(sys.argv[1],"r")
for i in myfile:
	lndata=i.strip().split("\t")
	if lndata[3] not in marker:
		marker[lndata[3]]={}

	no=0
	for gene in marker[lndata[3]]:
		if similar(gene, lndata[1]) > 0.7:
			no=1
	#		print(gene+"\t"+lndata[1]+"\t"+str(similar(gene, lndata[1])))
	if no==0: 
		if lndata[1] not in marker[lndata[3]]:
			marker[lndata[3]][lndata[1]]={}
		marker[lndata[3]][lndata[1]]=1
for m in marker:
	print(m,end="\t")
	glist=[]
	for g in marker[m]:
		glist.append(g)
	print(":".join(glist))
