open(FILE,$ARGV[0]);
my %seen;
while(<FILE>)
{
chomp();
my @line=split("/".$ARGV[2]."/",$_);
if(!$seen{$line[$ARGV[1]]})
{
 print $_."\n";
 $seen{$line[$ARGV[1]]}=1; 
}
}
close FILE;

if($ARG[0] eq "")
{
 print "USE remove-duplicate file column sep"
}
