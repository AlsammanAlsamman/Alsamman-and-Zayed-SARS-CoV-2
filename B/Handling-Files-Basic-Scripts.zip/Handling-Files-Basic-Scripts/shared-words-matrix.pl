#!/usr/bin/perl
open(FILE,$ARGV[0]);
my %data;
my %markers;
my @traits;
while(<FILE>)
{
chomp();
my @line=split(/\t/,$_);
push(@{$data{$line[0]}},$line[1]);
push(@{$markers{$line[1]}},$line[0]);
push(@traits,$line[0]);
}
close FILE;

open(MFILE,">".$ARGV[0]."MATRIX.csv");
my @items = keys(%data);
print MFILE "\t".join("\t",@items)."\n";
foreach my $k1 (@items)
{
print MFILE $k1."\t";
	foreach my $k2 (@items)
	{
	print MFILE compare_markers(\@{$data{$k1}},\@{$data{$k2}})."\t"; 
	 
	}
print MFILE "\n";
}
close MFILE;

open(MCFILE,">".$ARGV[0]."MARKER-COUNT.csv");
foreach my $m (keys(%markers))
{
  my @traits=@{$markers{$m}};
  my $count=$#traits+1;
  print MCFILE $m."\t".$count."\t".join("\&",@traits)."\n";
}
close MCFILE;



sub compare_markers
{
my ($list1,$list2)=@_;
my @list1=@{$list1};
my @list2=@{$list2};
my $count;
foreach my $item1(@list1)
{
	foreach my $item2(@list2)
	{
           if($item1 eq $item2){$count++};
	}
}

return  $count;
}

if($ARGV[0] eq "")
{
print "use perl shared-words.pl [DATA.txt]\n";
print "porpose : get the matrix from two line column\n";
print "#############\n";
print "FORMAT\n";
print "T1	S2-766
T1	SCoT17-1639
T1	SCoT17-170
T1	S1-467
T1	S7-342
T1	SCoT17-1986
T1	SCoT20-719
T1	SCoT17-1423
T10	S2-766
T10	SCoT17-449
T11	S2-766
T11	S7-342
\n";

}
