#!/usr/bin/python3
import sys
from collections import defaultdict

mydict={}
filen=0
for f in sys.argv[1:]:
	with open(f,"r") as myfile:
		filen+=1
		for line in myfile:
			first_c=line.strip().split("\t")[0]
			second_c=line.strip().split("\t")[1]
			if first_c in mydict:
				mydict[first_c][filen]=second_c
			else:
				mydict[first_c]={}
				mydict[first_c][filen]=second_c

for k,v in mydict.items():
	print(k,"\t",end="\t")
	for fn in range(1,filen+1):
		if fn in mydict[k]:
			print(mydict[k][fn],end="\t")
		else:
			print("0",end="\t")
	print()	
				
