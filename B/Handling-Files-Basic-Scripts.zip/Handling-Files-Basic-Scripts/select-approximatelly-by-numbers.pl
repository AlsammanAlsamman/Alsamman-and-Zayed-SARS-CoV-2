use strict;
my @list;
open(FILELIST,$ARGV[0]);
while(<FILELIST>)
{
chomp();
push(@list,$_);
}
close FILELIST;

my @wordlist;
if($ARGV[4] ne "")
{
open(WORDLIST,$ARGV[4]);
while(<WORDLIST>)
{
chomp();
push(@wordlist,$_);
}
close WORDLIST;

}

open(FILE,$ARGV[1]);
while(<FILE>)
{
chomp();
my @line=split(/\t/,$_);
foreach my $l (@list)
{
 my $sub=$line[$ARGV[2]]-$l;
    $sub=~s/-//g;
 if($sub <= $ARGV[3])
 {
  if($ARGV[4] ne "")
  {
  my $print=0;
  foreach my $w (@wordlist)
  {

  if($_=~m/$w/i)
   {
   $print=1;
     
   }
  }
   if($print==1)
   {
    print $l."\t".sprintf("%0.2f",$sub)."\t".$_."\n";
   }
}
  else
{
  print $l."\t".sprintf("%0.2f",$sub)."\t".$_."\n";
}

 }
}
}
close FILE;

if($ARGV[0] eq "")
{
print "use: get rows where specific column exists in a list of numbers with some missmatch and optional wordlist\n";
print "USAGE: script list file columnindex missvalue wordlist(optional)\n";
}
