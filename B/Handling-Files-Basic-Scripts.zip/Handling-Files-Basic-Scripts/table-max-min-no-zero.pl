use strict;
open(FILE,$ARGV[0]);
my %table;
my @headers;
my @rows;
my $l=0;
while(<FILE>)
{
my @space;
chomp();
my @line=split(/\,/,$_);
if($l==0){@headers=@line}else
{
 my $rowname=$line[0];
 foreach my $value(1..$#line)
 {
  $table{$rowname}{$headers[$value]}=$line[$value];
 }
 push(@rows,$rowname);
}
$l++;
}
close FILE;


#print join("\t",@headers)."\n";
foreach my $r(@rows)
{
my @rowvaluse;
print $r."\t";
foreach my $h(1..$#headers)
{
#print $table{$r}{$headers[$h]}."\t";
push(@rowvaluse,$table{$r}{$headers[$h]});
}
print $headers[max(@rowvaluse)+1]."\t".$rowvaluse[max(@rowvaluse)]."\t";
print $headers[min(@rowvaluse)+1]."\t".$rowvaluse[min(@rowvaluse)]."\n"; 
#print min(@rowvaluse)."\n";
# print "\n";
}




sub max{
my $max=0;
my $ii=0;
my $maxi=0;
foreach my $i (@_)
{
 if($i>$max){$max=$i,$maxi=$ii;}
 $ii++;
}
return $maxi;
}

sub min{

my $max=100;
my $ii=0;
my $maxi=0;
foreach my $i (@_)
{
 
 if($i<$max&& $i  ne ""&&$i !=0 ){$max=$i,$maxi=$ii;}
 
 $ii++;
}
return $maxi;
}

if($ARGV[0] eq "")
{
 print("use : reporting the highest and lowest columns for each row\n");
 print ("the row seperated by \,\n");
 print ("script file");
}
