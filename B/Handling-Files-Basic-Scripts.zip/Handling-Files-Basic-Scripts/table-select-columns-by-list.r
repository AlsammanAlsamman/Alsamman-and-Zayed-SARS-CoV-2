#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
if (length(args)==0) {
  stop()
}

table=read.table(args[1],header=TRUE, row.names=1,sep="\t")
list=read.table(args[2])
newtable=table[,list$V1]
write.table(newtable,paste(args[1],"selected-columns.csv"),sep="\t")
