open(FILE,$ARGV[0]);
my %data;
my @line;
while(<FILE>)
{
chomp();
@line=split("\,",$_);
$data{$line[0]}{$line[1]}=$line[2];
}
close FILE;

my @heads=keys(%{$data{$line[0]}});
print "PrimerName\t".join("\t",@heads)."\n";
foreach my $p (keys(%data))
{
print $p."\t";
foreach my $h (@heads)
{
 print $data{$p}{$h}."\t";
}
print "\n";
}

if($ARGV[0] eq "")
{
print "It combine data where the firsr column is a primername/indive , the second is a repeated catogaory ";

}
