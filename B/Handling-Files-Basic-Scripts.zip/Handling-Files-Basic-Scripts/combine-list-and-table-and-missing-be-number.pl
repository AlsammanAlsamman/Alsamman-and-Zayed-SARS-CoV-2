use strict;



my %list=read_file(shift);
#read_table
my %table=read_file(shift);
my $missing_vale=shift;
foreach my $item(keys(%list))
{
 if($table{$item})
   {
     print $item."\t".$table{$item}."\n";
   }
 if(!$table{$item})
   {
    print $item."\t".$missing_vale."\n";
   }
}

sub read_file
{
my($file)=@_;
open(FILE,$file);
my %data;
while(<FILE>)
{
chomp();
my @line=split(/\t/,$_);
   if(!$line[1]){$line[1]=1};
   $data{$line[0]}=$line[1];
}
close FILE;
return %data;
}



