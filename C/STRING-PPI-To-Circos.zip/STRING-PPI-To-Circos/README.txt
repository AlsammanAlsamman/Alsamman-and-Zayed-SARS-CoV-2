string-anno-table-to-circos.py	Preparing Annotation tables produced by STRING database online to be plotted
string-anno-to-table-single-gene.py	Preparing Annotation tables produced by STRING database online to be plotted
