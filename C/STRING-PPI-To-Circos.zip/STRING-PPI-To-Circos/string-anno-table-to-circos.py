#!/usr/bin/python3
import sys
import math
myfile=open(sys.argv[1],"r")
ideo={}
genesideo={}
count=1
for line in myfile :
	data=line.strip().split("\t")
	data[3]=data[3][1:30].replace(" ","_")
	data[2]=data[2][1:30].replace(" ","_")
	if data[1] not in ideo:
		ideo[data[1]]={}
		ideo[data[1]]["start"]=0
		ideo[data[1]]["end"]=1
	if data[3] not in ideo[data[1]]:
		ideo[data[1]]["start"]+=1
		ideo[data[1]]["end"]+=1
		ideo[data[1]][data[3]]=1
	log10p=-1*math.log10(float(data[5].strip()))
	if data[2] not in genesideo:
		genesideo[data[2]]=str(count)+"\t"+str(count+1)
		count+=1
	
	print(str(ideo[data[1]]["start"])+"\t"+str(ideo[data[1]]["end"])+"\t"+"\t".join(data)+"\t"+str(log10p)+"\t"+genesideo[data[2]])
