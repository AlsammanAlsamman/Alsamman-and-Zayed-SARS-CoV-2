#!/usr/bin/python3
import sys
myfile=open(sys.argv[1],"r")
for line in myfile :
	data=line.split("\t")	
	term=data[1]
	if "/" in term:
		term=term.split("/")[-1]
	genes=data[5]
	if "matching proteins in your network (IDs)" not in genes:
		genes=genes.split(",")
	else:
		continue
	filename=sys.argv[1]
	foldername=""
	if "/" in filename:
		path=filename.split("/")
		foldername=path[len(path)-2]
		filename=path[-1]
		foldername+="\t"
	for g in genes:
		print(foldername+filename+"\t"+g+"\t"+term.replace(" ","_")+"\t"+data[2]+"\t"+data[4])
