
# load libraries
library(plyr)
library(reshape2)
library(UpSetR)

# make a list of input files to be read
filelist = list.files(pattern = "*.csv")

# make a 3 column table of listname,gene,1
res<-lapply(filelist, function(x){
 data.frame(
  set=x,
  geneID=as.character(read.table(x)[,1]),
  val=1)
})

res<-ldply(res)

# turn the 3 column long table into a wide
res1<-acast(res,geneID~set,value.var="val",fill=0) 

# force as dataframe
res1<-as.data.frame(res1)

# 1st column must be a name
res1$name=rownames(res1)

# rearrange columns
res2=res1[,c(ncol(res1),1:(ncol(res1)-1))]

pdf("gene_intersections.pdf")
#make the plot with 6 sets
upset(res2,nsets = 6)
dev.off()

