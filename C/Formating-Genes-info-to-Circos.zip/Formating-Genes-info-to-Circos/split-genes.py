import sys

def function (unscaledNum, minAllowed, maxAllowed):
	return int(((maxAllowed - minAllowed) * (unscaledNum - 1.3012495816) / (32.6246108312 - 1.3012495816) + 1.3012495816))



gos={}
genename={}
color =	{
"GO:BP":"chr1",
"KEGG":"chr2",
"REAC":"chr3",
"WP":"chr4",
"GO:MF":"chr5",
"GO:CC":"chr6",
"HP":"chr7",
"MIRNA":"chr8",
"CORUM":"chr9",
"genes":"chr10"

}

gcount=0
myfile=open("COVID-19.csv")
for line in myfile:
	line=line.strip()	
	go=line.split("\t")[0]
	gene=line.split("\t")[10]
	if line.split("\t")[1] not in gos:
		gos[line.split("\t")[1]]=0


	gos[line.split("\t")[1]]+=1
#	print(line.split("\t")[1]+"\t"+str(gos[line.split("\t")[1]])+"\t"+str(gos[line.split("\t")[1]]+1)+"\t"+line.split("\t")[2])
	for g in gene.split(",") :
		if g not in genename:
			gcount+=1			
			genename[g]=gcount
			
		#gene ontology

#info group
		#print(line.split("\t")[1]+"\t"+line.split("\t")[2]+"\t"+str(gos[line.split("\t")[1]])+"\t"+str(gos[line.split("\t")[1]]+1),end="\t")
		#gene
#		print("genes\t"+g+"\t"+"\t"+str(genename[g])+"\t"+str(genename[g]+1),end="\t") 

#old color
#		print("color="+color[line.split("\t")[1]],end="\t") 		
		normalized = function(float(line.split("\t")[5]),1,5)
#		print("color="+color[line.split("\t")[1]]+"_a"+str((5-normalized+1))+"\t"+str(normalized),end="")
		

		#count and p-value of gos
		#print(str(int(float(line.split("\t")[8]))),end="")
		

		#special link color for some
		
		print()

#str(gos[line.split("\t")[1]]+1)+"\t"+go+"\t"+str(gcount)+"\t"+str(gcount+1)+"\t"+g




